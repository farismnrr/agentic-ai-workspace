# Masih Awam Workspace Reference Bundle

## Source identity

- Project: agentic-ai-workspace
- Branch: dev
- Source commit: fff7a2b84287b4bae78a0b014cbb00599756fa66

## Included files

The bundle contains 30 source files copied at their original relative paths:

- Design system (16): design guide, app theme, font faces, all 11 current shared UI files, frontend package manifest, and Vite configuration.
- Architecture docs (2): the system design guide and README.
- Go backend and HTTP serving (8): Go module and Makefile, embedded web asset loader and placeholder, and four HTTP server files.
- Database (4): database open logic, migration runner, initial accounts migration, and migration tests.

### Exact source paths

docs/design-system.md
web/src/app.css
web/src/shared/theme/fonts.css
web/src/shared/ui/BrandLink.svelte
web/src/shared/ui/EmptyState.svelte
web/src/shared/ui/Icon.svelte
web/src/shared/ui/Illustration.svelte
web/src/shared/ui/LazySection.svelte
web/src/shared/ui/LoadingScreen.svelte
web/src/shared/ui/LogoMark.svelte
web/src/shared/ui/Marker.svelte
web/src/shared/ui/SegmentedControl.svelte
web/src/shared/ui/SkeletonList.svelte
web/src/shared/ui/icon-names.ts
web/package.json
web/vite.config.ts
docs/system-design.md
README.md
go.mod
Makefile
internal/platform/webassets/assets.go
internal/platform/webassets/dist/placeholder.txt
internal/platform/httpserver/server.go
internal/platform/httpserver/routes.go
internal/platform/httpserver/spa.go
internal/platform/httpserver/spa_test.go
internal/platform/database/database.go
internal/platform/database/migrate.go
internal/platform/database/migrations/001_accounts.sql
internal/platform/database/migrate_test.go

## Purpose of each group

- **Design system:** visual rules, central theme, fonts, reusable UI components, and frontend build configuration.
- **Architecture docs:** project overview and how its main parts fit together.
- **Go backend and HTTP serving:** build configuration, embedded frontend assets, API routes, health endpoint, and SPA fallback behavior.
- **Database:** SQLite initialization, numbered migration application, initial account tables, and migration behavior tests.

## Design-system entry points

- Theme values: web/src/app.css.
- Font faces: web/src/shared/theme/fonts.css.
- Reusable visual components: web/src/shared/ui/.
- Human-readable rules: docs/design-system.md.

## Runtime patterns

- **Go single binary, single port:** Vite builds the frontend and Go embeds those assets. Fiber serves API routes and the SPA through the same process and listener. Node is a build-time dependency, not a production server.
- **SQLite initialization and migrations:** opening the database creates its data directory and file, enables foreign keys, WAL journaling, and a busy timeout, then applies embedded numbered SQL migrations. A checksum journal detects changed or missing applied migrations; existing migrations are append-only.

## Dependencies referenced but not included

- Go modules in go.mod, including Fiber v3, the pure-Go SQLite driver, and transitive dependencies. No module cache or vendored dependencies are included.
- Frontend packages in web/package.json, including Svelte, Vite, Tailwind CSS, daisyUI, and font packages. No node_modules, lockfile, or build output is included.
- Building requires the Go toolchain and Node.js/package manager. The embedded frontend output is absent except for the required placeholder.

## Source integrity

All 30 source files are byte-for-byte copies of the source commit above. No source files were modified for this bundle. This manifest is the only added file.
