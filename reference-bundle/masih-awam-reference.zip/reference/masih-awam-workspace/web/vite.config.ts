import { fileURLToPath, URL } from 'node:url';

import tailwindcss from '@tailwindcss/vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [tailwindcss(), svelte()],
  build: {
    outDir: fileURLToPath(
      new URL('../internal/platform/webassets/dist', import.meta.url),
    ),
    emptyOutDir: false,
  },
});
